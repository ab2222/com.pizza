package com.pizza.controller;

import com.pizza.model.FoodItem;
import com.pizza.model.User;
import com.pizza.repository.FoodItemRepository;
import com.pizza.service.CartService;
import com.pizza.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    private FoodItemRepository foodItemRepository;

    @Autowired
    private CartService cartService;

    @GetMapping("/fooditems")
    public String showFoodItems(Model model) {
        model.addAttribute("foodItems", foodItemRepository.findAll());
        return "fooditems";
    }

    @PostMapping("/addtocart")
    public String addToCart(@RequestParam Long foodItemId, HttpSession session) {
        FoodItem foodItem = foodItemRepository.findById(foodItemId).orElse(null);
        if (foodItem != null) {
            User user = (User) session.getAttribute(Constants.USER_SESSION_KEY);
            if (user != null) {
                cartService.addItem(user, foodItem);
            } else {
                cartService.addItem(session, foodItem);
            }
        }
        return "redirect:/customer/fooditems";
    }

    @GetMapping("/viewcart")
    public String viewCart(HttpSession session, Model model) {
        User user = (User) session.getAttribute(Constants.USER_SESSION_KEY);
        if (user != null) {
            model.addAttribute("cartItems", cartService.getCartItems(user));
        } else {
            model.addAttribute("cartItems", cartService.getCartItems(session));
        }
        return "viewcart";
    }

    @PostMapping("/modifycart")
    public String modifyCart(@RequestParam Long cartItemId, @RequestParam int quantity, HttpSession session) {
        User user = (User) session.getAttribute(Constants.USER_SESSION_KEY);
        if (user != null) {
            cartService.modifyItemQuantity(user, cartItemId, quantity);
        } else {
            cartService.modifyItemQuantity(session, cartItemId, quantity);
        }
        return "redirect:/customer/viewcart";
    }

    @PostMapping("/removefromcart")
    public String removeFromCart(@RequestParam Long cartItemId, HttpSession session) {
        User user = (User) session.getAttribute(Constants.USER_SESSION_KEY);
        if (user != null) {
            cartService.removeItem(user, cartItemId);
        } else {
            cartService.removeItem(session, cartItemId);
        }
        return "redirect:/customer/viewcart";
    }
}
