package com.pizza.controller;
import java.sql.PreparedStatement;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pizza.model.User;
import com.pizza.model.User.UserType;
import com.pizza.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class LoginController {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private DataSource dataSource;

	@GetMapping("/login")
	public String showLoginForm(Model model, @RequestParam(required = false) String error) {
	    if (error != null) {
	        model.addAttribute("errorMessage", "Invalid username or password");
	    }
	    model.addAttribute("userTypeList", UserType.values());
	    return "login";
	}

	Logger logger = org.slf4j.LoggerFactory.getLogger(getClass());
	@PostMapping("/login")
	public String processLoginForm(@RequestParam String loginId, @RequestParam String password, @RequestParam UserType userType, HttpSession session, Model model) {
	    logger.info(loginId+"<>"+password+"<>"+userType);
		User user = null;
	    if (userType == UserType.ADMIN) {
	        // validate admin credentials from Oracle SQL plus
//	        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
//	        String query = "SELECT * FROM admin WHERE login_id=? AND password=?";
//	        List<User> users = jdbcTemplate.query(con -> {
//	            PreparedStatement ps = con.prepareStatement(query);
//	            ps.setString(1, loginId);
//	            ps.setString(2, password);
//	            return ps;
//	        }, new BeanPropertyRowMapper<>(User.class));
//
//	        if (users.size() > 0) {
//	            user = users.get(0);
//	        }
	    	logger.info(userRepository.findAll().toString());
	    	user = userRepository.findByLoginIdAndPassword(loginId, password);
	    } else {
	        // fetch user from database
	        user = userRepository.findByLoginIdAndPassword(loginId, password);
	    }

	    if (user == null) {
	    	logger.info("getting error because user is null");
	        model.addAttribute("errorMessage", "Invalid username or password");
	        return "login";
	    }

	    session.setAttribute("user", user);
	    if (user.getUserType() == UserType.ADMIN) {
	    	logger.info("redirecting to adminhome");
	        return "redirect:/admin/adminhome";
//	    	return "adminhome";
	    } else {
	    	logger.info("redirecting to userhome");
	        return "userhome";
	    }
	}
	@GetMapping("/signup")
	public String showSignupForm(Model model) {
		model.addAttribute("userTypeList", UserType.USER);
		model.addAttribute("user", new User());
		return "signup";
	}

	@PostMapping("/signup")
	public String processSignupForm(@ModelAttribute User user) {
		user.setUserType(UserType.USER);
		userRepository.save(user);
		return "redirect:/login";
	}
}
