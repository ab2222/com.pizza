package com.pizza.repository;

import com.pizza.model.PizzaStore;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PizzaStoreRepository extends JpaRepository<PizzaStore, Long> {

}
